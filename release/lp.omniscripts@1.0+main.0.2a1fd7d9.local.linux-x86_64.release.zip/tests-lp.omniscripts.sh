#!/bin/bash
set -e
SCRIPT_DIR=$(dirname ${BASH_SOURCE})
exec "$SCRIPT_DIR/kit/kit"  --enable omni.kit.test --/app/enableStdoutOutput=0 --/exts/omni.kit.test/testExts/0='lp.omniscripts' --ext-folder "$SCRIPT_DIR/exts"  --ext-folder "$SCRIPT_DIR/apps"  --/exts/omni.kit.test/testExtOutputPath="$SCRIPT_DIR/../../../_testoutput"  --portable-root "$SCRIPT_DIR/"  --/telemetry/mode=test "$@"
